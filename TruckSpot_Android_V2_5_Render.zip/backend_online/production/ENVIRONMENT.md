# TruckSpot V1.7 — produção

Variáveis no servidor:
- DATABASE_URL
- API_BASE_URL
- JWT_SECRET
- CORS_ORIGINS

Nunca colocar segredos dentro da app Android. Em produção usar HTTPS.
