#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then echo "Usage: $0 backup.sql"; exit 1; fi
set -a; source .env; set +a
cat "$1" | docker compose -f docker-compose.production.yml exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB"
echo "Restore completed"
