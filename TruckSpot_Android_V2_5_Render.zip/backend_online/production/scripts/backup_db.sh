#!/usr/bin/env bash
set -euo pipefail
mkdir -p backups
set -a; source .env; set +a
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
docker compose -f docker-compose.production.yml exec -T db pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" > "backups/truckspot_${STAMP}.sql"
echo "Backup created: backups/truckspot_${STAMP}.sql"
