# TruckSpot V2.3 — publicação do backend

1. Escolher uma VPS/cloud com Docker e um IP público.
2. Criar um domínio/subdomínio, por exemplo `api.truckspot.pt`, apontando para o IP.
3. Copiar `.env.example` para `.env` e substituir todos os `CHANGE_ME`.
4. Definir `TRUCKSPOT_DOMAIN` para o domínio real.
5. Executar `docker compose -f docker-compose.production.yml up -d --build`.
6. Confirmar `https://DOMINIO/health` e esperar `{"ok":true,...}`.
7. Na app Android V2.2, definir a API como `https://DOMINIO`.

O Caddy trata automaticamente dos certificados TLS quando o DNS e as portas 80/443 estão corretamente configurados.

Importante: este pacote não cria uma conta cloud nem publica o servidor sozinho. É necessário um fornecedor de VPS/cloud e um domínio controlados pelo proprietário do projeto.
