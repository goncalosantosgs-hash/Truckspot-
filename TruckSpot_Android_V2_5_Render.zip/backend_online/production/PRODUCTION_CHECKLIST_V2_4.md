# TruckSpot V2.4 — checklist de publicação

## VPS
- Ubuntu 24.04 LTS (ou equivalente)
- 2 vCPU / 4 GB RAM recomendado para a fase piloto
- IP público
- Docker + Compose plugin
- Firewall: TCP 22, 80 e 443 apenas

## DNS
Criar `api.<dominio>` com um registo A para o IP da VPS.

## Configuração
1. `cp .env.example .env`
2. Gerar uma password PostgreSQL longa.
3. Gerar `JWT_SECRET` aleatório longo.
4. Definir `TRUCKSPOT_DOMAIN=api.<dominio>`.
5. Definir `CORS_ORIGINS` apenas para origens necessárias.

## Arranque
`docker compose -f docker-compose.production.yml up -d --build`

## Verificação
`curl https://api.<dominio>/health`

## Dados de demonstração (opcional)
Dentro do container API:
`docker compose -f docker-compose.production.yml exec api python seed_demo.py`

Os parques `TruckSpot Demo ...` são fictícios e servem apenas para testes.

## Backup
`./scripts/backup_db.sh`

## Segurança
- Não colocar `.env` no Git.
- Não expor PostgreSQL na Internet.
- Usar HTTPS em produção.
- Substituir dados fictícios por parques verificados antes do lançamento público.
