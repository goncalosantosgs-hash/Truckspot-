# TruckSpot V2.4 — publicação online

1. Criar uma VPS com Docker (2 vCPU / 4 GB RAM é uma base adequada para o piloto).
2. Criar um domínio/subdomínio, por exemplo `api.truckspot.pt`, apontado para o IP da VPS.
3. Copiar `backend_online/production` para o servidor.
4. `cp .env.example .env` e preencher os segredos.
5. Executar `docker compose -f docker-compose.production.yml up -d --build`.
6. Confirmar `https://DOMINIO/health`.
7. Opcionalmente executar `docker compose -f docker-compose.production.yml exec api python seed_demo.py`.
8. Na app, usar `https://DOMINIO` como API.

O Caddy pede/renova o certificado TLS automaticamente quando o DNS e as portas 80/443 estão corretos.

Este pacote não cria uma conta cloud, não compra domínio e não publica sozinho.
