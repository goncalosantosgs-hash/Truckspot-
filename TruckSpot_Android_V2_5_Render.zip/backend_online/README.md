# TruckSpot V1.5 — Backend Online

Esta pasta prepara a ligação da app Android a um servidor TruckSpot real.

## Variáveis
- TRUCKSPOT_API_BASE_URL: URL HTTPS da API
- TRUCKSPOT_API_TIMEOUT_MS: timeout de pedidos

## Fluxo
1. App pede parques próximos: GET /api/v1/parks
2. App abre parque: GET /api/v1/parks/{id}
3. App envia disponibilidade: POST /api/v1/parks/{id}/availability
4. Servidor recalcula estado/confiança
5. Outros motoristas recebem o estado atualizado.

A API deve ser HTTPS em produção. Nunca colocar passwords ou chaves privadas dentro da app.
