import os, time
from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field
from .db import conn, init_db
from .security import hash_password, verify_password, make_token, read_token
from .trust import compute, distance_m

app=FastAPI(title='TruckSpot API', version='2.3.0')
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or ['*'], allow_credentials=bool(origins), allow_methods=['GET','POST','OPTIONS'], allow_headers=['*'])
RATE_WINDOW=60; RATE_MAX=int(os.getenv('REPORT_RATE_LIMIT','10')); _rate={}

class Register(BaseModel):
    public_name: str = Field(min_length=2,max_length=80)
    email: EmailStr
    password: str = Field(min_length=8,max_length=128)
class Login(BaseModel): email: EmailStr; password: str
class Report(BaseModel):
    status: str; exact_free: int|None = Field(default=None, ge=0); latitude: float|None=None; longitude: float|None=None
class Event(BaseModel):
    event: str = Field(pattern='^(ENTERED|LEFT)$'); latitude: float|None=None; longitude: float|None=None

def auth(authorization):
    if not authorization or not authorization.lower().startswith('bearer '): raise HTTPException(401,'Authentication required')
    try: return read_token(authorization.split(' ',1)[1])
    except Exception: raise HTTPException(401,'Invalid or expired token')

def rate_limit(driver_id):
    now=time.time(); bucket=_rate.setdefault(driver_id,[]); bucket[:]=[t for t in bucket if now-t<RATE_WINDOW]
    if len(bucket)>=RATE_MAX: raise HTTPException(429,'Too many reports; please wait')
    bucket.append(now)

@app.on_event('startup')
def startup():
    last=None
    for _ in range(15):
        try: init_db(); return
        except Exception as e: last=e; time.sleep(2)
    raise last

@app.get('/health')
def health(): return {'ok':True,'version':'2.3.0'}

@app.post('/api/v1/auth/register')
def register(x:Register):
    with conn() as c:
        try:
            row=c.execute('INSERT INTO drivers(public_name,email,password_hash) VALUES(%s,%s,%s) RETURNING id,public_name,email',(x.public_name,x.email.lower(),hash_password(x.password))).fetchone(); c.commit()
        except Exception: c.rollback(); raise HTTPException(409,'Email already registered')
    return {'driver':dict(zip(['id','public_name','email'],row)),'token':make_token(row[0])}

@app.post('/api/v1/auth/login')
def login(x:Login):
    with conn() as c: row=c.execute('SELECT id,public_name,email,password_hash FROM drivers WHERE email=%s',(x.email.lower(),)).fetchone()
    if not row or not verify_password(x.password,row[3]): raise HTTPException(401,'Invalid credentials')
    return {'driver':{'id':row[0],'public_name':row[1],'email':row[2]},'token':make_token(row[0])}

@app.get('/api/v1/parks')
def parks():
    with conn() as c:
        rows=c.execute('SELECT p.id,p.name,p.country_code,p.latitude,p.longitude,p.capacity,s.estimated_free,s.status,s.confidence,s.last_update FROM parks p LEFT JOIN park_current_state s ON s.park_id=p.id WHERE p.active=true ORDER BY p.id').fetchall()
    keys=['id','name','country_code','latitude','longitude','capacity','estimated_free','status','confidence','last_update']; return [dict(zip(keys,r)) for r in rows]

@app.get('/api/v1/parks/{park_id}')
def park(park_id:int):
    with conn() as c:
        r=c.execute('SELECT p.id,p.name,p.country_code,p.latitude,p.longitude,p.capacity,p.services_json,s.estimated_free,s.status,s.confidence,s.last_update FROM parks p LEFT JOIN park_current_state s ON s.park_id=p.id WHERE p.id=%s AND p.active=true',(park_id,)).fetchone()
    if not r: raise HTTPException(404,'Park not found')
    keys=['id','name','country_code','latitude','longitude','capacity','services','estimated_free','status','confidence','last_update']; return dict(zip(keys,r))

@app.post('/api/v1/parks/{park_id}/availability')
def report(park_id:int,x:Report,authorization:str|None=Header(None)):
    driver_id=auth(authorization); rate_limit(driver_id)
    allowed={'MANY','SOME','FEW','FULL','EXACT'}
    if x.status not in allowed: raise HTTPException(422,'Invalid status')
    with conn() as c:
        park=c.execute('SELECT id,capacity,latitude,longitude FROM parks WHERE id=%s AND active=true',(park_id,)).fetchone()
        if not park: raise HTTPException(404,'Park not found')
        if x.status=='EXACT' and x.exact_free is None: raise HTTPException(422,'exact_free required')
        if x.exact_free is not None and x.exact_free>park[1]: raise HTTPException(422,'Availability exceeds capacity')
        c.execute('INSERT INTO availability_reports(park_id,driver_id,status,exact_free,latitude,longitude) VALUES(%s,%s,%s,%s,%s,%s)',(park_id,driver_id,x.status,x.exact_free,x.latitude,x.longitude))
        rows=c.execute('SELECT r.reported_at,r.status,r.exact_free,r.latitude,r.longitude,d.reliability_score FROM availability_reports r JOIN drivers d ON d.id=r.driver_id WHERE r.park_id=%s ORDER BY r.reported_at DESC LIMIT 30',(park_id,)).fetchall()
        reports=[{'reported_at':r[0],'status':r[1],'exact_free':r[2],'distance_m':distance_m(r[3],r[4],park[2],park[3]),'reliability':r[5]} for r in rows]
        state=compute(reports,park[1])
        c.execute('INSERT INTO park_current_state(park_id,estimated_free,status,confidence,last_update,report_count) VALUES(%s,%s,%s,%s,now(),%s) ON CONFLICT(park_id) DO UPDATE SET estimated_free=EXCLUDED.estimated_free,status=EXCLUDED.status,confidence=EXCLUDED.confidence,last_update=EXCLUDED.last_update,report_count=EXCLUDED.report_count',(park_id,state['estimated_free'],state['status'],state['confidence'],state['report_count']))
        c.execute('UPDATE drivers SET reports_count=reports_count+1 WHERE id=%s',(driver_id,)); c.commit()
    return state

@app.get('/api/v1/parks/{park_id}/availability')
def availability(park_id:int):
    with conn() as c:
        rows=c.execute('SELECT r.id,r.reported_at,r.status,r.exact_free,r.latitude,r.longitude,d.public_name FROM availability_reports r JOIN drivers d ON d.id=r.driver_id WHERE r.park_id=%s ORDER BY r.reported_at DESC LIMIT 50',(park_id,)).fetchall()
    keys=['id','reported_at','status','exact_free','latitude','longitude','driver']; return [dict(zip(keys,r)) for r in rows]

@app.post('/api/v1/parks/{park_id}/events')
def event(park_id:int,x:Event,authorization:str|None=Header(None)):
    driver_id=auth(authorization)
    with conn() as c:
        if not c.execute('SELECT 1 FROM parks WHERE id=%s AND active=true',(park_id,)).fetchone(): raise HTTPException(404,'Park not found')
        c.execute('CREATE TABLE IF NOT EXISTS park_events (id BIGSERIAL PRIMARY KEY, park_id BIGINT NOT NULL REFERENCES parks(id), driver_id BIGINT NOT NULL REFERENCES drivers(id), event VARCHAR(10) NOT NULL, latitude DOUBLE PRECISION, longitude DOUBLE PRECISION, created_at TIMESTAMPTZ NOT NULL DEFAULT now())')
        c.execute('INSERT INTO park_events(park_id,driver_id,event,latitude,longitude) VALUES(%s,%s,%s,%s,%s)',(park_id,driver_id,x.event,x.latitude,x.longitude)); c.commit()
    return {'ok':True,'event':x.event}
