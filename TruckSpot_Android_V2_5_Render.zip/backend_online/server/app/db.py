import os
import psycopg
from contextlib import contextmanager

DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://truckspot:truckspot@db:5432/truckspot')

SCHEMA = '''
CREATE TABLE IF NOT EXISTS drivers (
 id BIGSERIAL PRIMARY KEY,
 public_name VARCHAR(80) NOT NULL,
 email VARCHAR(255) UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 reliability_score DOUBLE PRECISION NOT NULL DEFAULT 0.5,
 reports_count INTEGER NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS parks (
 id BIGSERIAL PRIMARY KEY,
 name VARCHAR(160) NOT NULL,
 country_code CHAR(2) NOT NULL DEFAULT 'PT',
 latitude DOUBLE PRECISION NOT NULL,
 longitude DOUBLE PRECISION NOT NULL,
 capacity INTEGER NOT NULL CHECK (capacity > 0),
 services_json JSONB NOT NULL DEFAULT '{}'::jsonb,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS availability_reports (
 id BIGSERIAL PRIMARY KEY,
 park_id BIGINT NOT NULL REFERENCES parks(id),
 driver_id BIGINT NOT NULL REFERENCES drivers(id),
 reported_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 status VARCHAR(10) NOT NULL CHECK (status IN ('MANY','SOME','FEW','FULL','EXACT')),
 exact_free INTEGER,
 latitude DOUBLE PRECISION,
 longitude DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS idx_reports_park_time ON availability_reports(park_id, reported_at DESC);
CREATE TABLE IF NOT EXISTS park_current_state (
 park_id BIGINT PRIMARY KEY REFERENCES parks(id),
 estimated_free INTEGER,
 status VARCHAR(10) NOT NULL DEFAULT 'UNKNOWN',
 confidence DOUBLE PRECISION NOT NULL DEFAULT 0,
 last_update TIMESTAMPTZ,
 report_count INTEGER NOT NULL DEFAULT 0
);
'''

@contextmanager
def conn():
    with psycopg.connect(DATABASE_URL) as c:
        yield c

def init_db():
    with conn() as c:
        c.execute(SCHEMA)
        c.commit()
