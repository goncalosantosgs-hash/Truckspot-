from datetime import datetime, timezone
import math

def distance_m(lat1, lon1, lat2, lon2):
    if None in (lat1,lon1,lat2,lon2): return None
    r=6371000
    p1,p2=math.radians(lat1),math.radians(lat2)
    dp=math.radians(lat2-lat1); dl=math.radians(lon2-lon1)
    a=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.asin(math.sqrt(a))

def report_weight(age_min, distance):
    recency = 1 if age_min <= 15 else .85 if age_min <=45 else .55 if age_min <=120 else .2
    if distance is None: geo=1
    elif distance<=100: geo=1
    elif distance<=300: geo=.85
    elif distance<=800: geo=.6
    elif distance<=1500: geo=.3
    else: geo=0
    return recency*geo

def compute(reports, capacity):
    now=datetime.now(timezone.utc); weighted=[]
    for r in reports:
        age=max(0,(now-r['reported_at']).total_seconds()/60)
        w=report_weight(age,r.get('distance_m'))
        if w<=0: continue
        if r['status']=='EXACT': value=r['exact_free']
        else: value={'MANY':max(1,round(capacity*.65)),'SOME':max(1,round(capacity*.35)),'FEW':max(0,round(capacity*.12)),'FULL':0}[r['status']]
        weighted.append((value,w,r.get('reliability',.5)))
    if not weighted: return {'estimated_free':None,'status':'UNKNOWN','confidence':0,'report_count':0}
    total=sum(w*(.85+.15*rel) for _,w,rel in weighted)
    estimate=round(sum(v*w*(.85+.15*rel) for v,w,rel in weighted)/total)
    spread=sum(abs(v-estimate)*w for v,w,_ in weighted)/sum(w for _,w,_ in weighted)
    agreement=max(0,1-spread/max(capacity,1))
    recency=sum(w for _,w,_ in weighted)/len(weighted)
    confidence=round(min(1,.40*recency+.25*min(1,len(weighted)/3)+.20*agreement+.15*sum(rel for _,_,rel in weighted)/len(weighted)),3)
    status='FULL' if estimate==0 else 'FEW' if estimate<=max(1,round(capacity*.12)) else 'SOME' if estimate<=round(capacity*.5) else 'MANY'
    return {'estimated_free':max(0,min(capacity,estimate)),'status':status,'confidence':confidence,'report_count':len(weighted)}
