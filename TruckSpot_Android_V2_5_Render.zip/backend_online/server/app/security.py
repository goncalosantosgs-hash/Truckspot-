import os, hashlib, hmac, base64, time, json
SECRET = os.getenv('JWT_SECRET', 'CHANGE_ME_IN_PRODUCTION')
TTL = int(os.getenv('JWT_TTL_SECONDS', '2592000'))

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 180000)
    return base64.b64encode(salt + digest).decode()

def verify_password(password: str, stored: str) -> bool:
    raw = base64.b64decode(stored.encode())
    salt, expected = raw[:16], raw[16:]
    actual = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 180000)
    return hmac.compare_digest(actual, expected)

def make_token(driver_id: int) -> str:
    # Compact HMAC token; avoids an extra JWT dependency while retaining signed expiry.
    header = {'alg':'HS256','typ':'TSJWT'}
    payload = {'sub': str(driver_id), 'exp': int(time.time()) + TTL}
    enc = lambda x: base64.urlsafe_b64encode(json.dumps(x,separators=(',',':')).encode()).rstrip(b'=').decode()
    body = enc(header)+'.'+enc(payload)
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return body+'.'+base64.urlsafe_b64encode(sig).rstrip(b'=').decode()

def read_token(token: str) -> int:
    parts = token.split('.')
    if len(parts) != 3: raise ValueError('invalid token')
    body = parts[0]+'.'+parts[1]
    expected = base64.urlsafe_b64encode(hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).digest()).rstrip(b'=').decode()
    if not hmac.compare_digest(expected, parts[2]): raise ValueError('invalid signature')
    payload = json.loads(base64.urlsafe_b64decode(parts[1]+'==='))
    if int(payload['exp']) < int(time.time()): raise ValueError('expired token')
    return int(payload['sub'])
