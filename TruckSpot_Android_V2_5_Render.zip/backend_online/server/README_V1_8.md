# TruckSpot Backend V1.8

Backend persistente para TruckSpot.

## Incluído
- PostgreSQL persistente
- Registo/login de motoristas
- Tokens assinados com expiração
- Passwords com PBKDF2-HMAC-SHA256
- Histórico de relatos de disponibilidade
- Estado atual por parque
- Trust Engine com recência, proximidade GPS, concordância e reputação
- Validação de capacidade

## Arranque
`docker compose -f production/docker-compose.production.yml up -d --build`

Definir `DATABASE_URL` e `JWT_SECRET` em ambiente de produção. Não usar o segredo de exemplo.
