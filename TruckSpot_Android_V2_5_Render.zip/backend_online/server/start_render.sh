#!/bin/sh
set -e
python seed_demo.py
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-10000}"
