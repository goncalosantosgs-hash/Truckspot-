import os
from app.db import conn, init_db

parks = [
    ("TruckSpot Demo Norte", "PT", 41.545, -8.426, 80, {"fuel": True, "food": True, "showers": True}),
    ("TruckSpot Demo Centro", "PT", 40.205, -8.429, 60, {"fuel": True, "food": True, "showers": False}),
    ("TruckSpot Demo Sul", "PT", 38.722, -9.139, 100, {"fuel": True, "food": True, "showers": True}),
]

if __name__ == "__main__":
    init_db()
    with conn() as c:
        for name, country, lat, lon, cap, services in parks:
            c.execute("""
                INSERT INTO parks(name,country_code,latitude,longitude,capacity,services_json)
                SELECT %s,%s,%s,%s,%s,%s::jsonb
                WHERE NOT EXISTS (SELECT 1 FROM parks WHERE name=%s)
            """, (name,country,lat,lon,cap,__import__('json').dumps(services),name))
        c.commit()
    print("Demo parks ready")
