# TruckSpot V2.5 — Render gratuito

Este pacote está preparado para um primeiro piloto online no Render.

## O que é criado
- Web Service FastAPI: `truckspot-api`
- PostgreSQL: `truckspot-db`
- HTTPS e subdomínio `*.onrender.com` fornecidos pelo Render
- `DATABASE_URL` ligado automaticamente ao Postgres
- `JWT_SECRET` gerado pelo Render
- Health check: `/health`
- Parques demo inseridos automaticamente no arranque

## Publicação
1. Criar uma conta no Render.
2. Colocar este projeto num repositório GitHub/GitLab/Bitbucket.
3. No Render: `New` → `Blueprint`.
4. Selecionar o repositório e o ficheiro `render.yaml` da raiz.
5. Confirmar os serviços `truckspot-api` e `truckspot-db` no plano Free.
6. Fazer o deploy.
7. Abrir o URL HTTPS atribuído ao `truckspot-api` e testar `/health`.

O comando de arranque usa a porta `$PORT` do Render e escuta em `0.0.0.0`.

## Limitações do piloto
O serviço web Free pode entrar em suspensão após 15 minutos sem tráfego e demora cerca de um minuto a acordar. O Postgres Free tem 1 GB e expira 30 dias depois da criação; não há backups no plano Free. Isto é adequado para teste, não para produção.

## Android
Depois do deploy, copiar o URL HTTPS do serviço para a configuração da API Android, por exemplo:
`https://truckspot-api.onrender.com`

Não incluir `/health` nem uma barra final no valor base.
