# Android ↔ TruckSpot

Desenvolvimento/emulador: http://10.0.2.2:8080
Produção: configurar a URL HTTPS real quando o servidor/domínio estiver provisionado.

Fluxo:
GET /api/v1/parks
GET /api/v1/parks/{id}
POST /api/v1/parks/{id}/availability
