# TruckSpot Android V1.4

Próximo marco: mapa real dentro da app.
- Leaflet + OpenStreetMap
- marcadores de parques
- estado de disponibilidade
- localização GPS do motorista
- preparação para ligar os marcadores à API TruckSpot

Os parques desta versão são dados de demonstração e não representam disponibilidade real.
