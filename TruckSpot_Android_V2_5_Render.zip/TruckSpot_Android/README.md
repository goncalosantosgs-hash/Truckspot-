# TruckSpot Android V1.3

Primeira base nativa Android do TruckSpot. A interface V1.2 é carregada como recurso local numa WebView e a aplicação pede permissões de localização/GPS e Internet.

## Abrir
Abra esta pasta no Android Studio e faça Build > Build APK(s).

Package: com.truckspot.app
Version: 1.3
Min Android: 8.0 (API 26)

Nota: este pacote é o projeto Android fonte; ainda não é o APK final assinado. O próximo passo é ligar o mapa real e o backend online e depois gerar o APK/AAB de produção.
