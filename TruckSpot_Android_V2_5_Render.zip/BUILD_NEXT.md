# TruckSpot V2.3 — próximo teste

## Backend
Publicar `backend_online/production` numa VPS/cloud com Docker e domínio HTTPS.

## Android
Abrir `TruckSpot_Android` no Android Studio, sincronizar Gradle e gerar APK de debug.

Depois configurar na app o endereço `https://api.seudominio` e testar:
- `/health`
- registo/login
- lista de parques
- envio de disponibilidade
- consulta de disponibilidade
- evento ENTERED/LEFT
